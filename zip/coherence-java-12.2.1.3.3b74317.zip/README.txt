Oracle Coherence 12.2.1.3.3 for Java

Oracle Coherence 12.2.1.3.3 for Java contains fixes for the following issues:
-----------------------------------------------------------------------------
29869261	COH-19552	Fixed an issue where federation may not transition to the ERROR state if the member is currently attempting to connect to the destination cluster.
29824256	COH-19512	Improved reporter performance for larger clusters containing a large number of remote MBeans.
29821593	COH-19509	Fixed an issue where federation may not transition to the ERROR state if the member is currently disconnected from the destination cluster (i.e. in DISCONNECTED state).
29817685	COH-19508	Fixed an issue where an OutOfMemoryError could be thrown during MessageBus connection migration.
29790376	COH-19464	Fixed an issue where EventDispatcher can timeout for events with long running EventInterceptors.
29701561	COH-19392	Fixed an issue where running a port scan tool against a Coherence*Extend ProxyService port may cause increased CPU and memory usage in the ProxyService.
29665969	COH-19347	Fixed an issue where cache entries larger than Elastic Data's maximum value size could not be federated.
29655463	COH-19338	Fixed an issue where a NullPointerException could be thrown from AbstractSocketBus$Connection.wakeup.
29646754	COH-19334	Fixed an issue where BinaryEntry.getExpiry() may return an incorrect value.
29623130	COH-19321	Fixed an issue where partition distribution could be stuck during cluster start or rolling restart.
29460667	COH-19209	Fixed an issue where a federation destination may be stuck in the DISCONNECTING state in some rare scenarios.
29450018	COH-19203	Fixed an issue where federation may not transition to PAUSED, STOPPED, or ERROR states in some rare scenarios.
29396990	COH-19135	Changed the federation replicateAll operation so that an exception will be thrown if federation is in a state (e.g. STOPPED or ERROR) where the replicateAll cannot be executed correctly.
29383613	COH-19128	Fixed an issue where federation was incorrectly reporting a gap in records received on the destination cluster.
29344441	COH-19075	Fixed an issue where federation ReplicateAll operations on a large cache service could result in OutOfMemoryErrors on the destination cluster.
29343125	COH-19072	Fixed an issue where a federation central topology hub participant may fail to federate data to leaf participants.
29333196	COH-19060	Reduced memory used by federation when collecting cache entries to send to remote participants.
29333194	COH-19059	Fixed an issue where the federation <participant/batch-size> setting was being ignored in most circumstances.
29333187	COH-19058	Added additional logging information for the case where an exception is thrown while preparing or sending cache entries to a remote federation participant.
29312232	COH-19036	Fixed an issue where a distributed cache service could be terminated by "java.lang.Error: Maximum lock count exceeded".
29286459	COH-19011	Fixed an issue where a cache service may be terminated when an exception is thrown from a CacheStore during index rebuild.
29227943	COH-18951	Fixed a performance issue for queries containing InFilter.
29206382	COH-18897	Fixed an issue where operations on off-heap cache using Berkley DB could fail with "Partial failure" after service restart.
29138643	COH-18866	Fixed an issue where an OutOfMemoryError in Direct buffer memory could happen with MessageBus.
29018620	COH-18823	Fixed an issue with OutOfMemoryError handling in <paged-external-scheme> when the overflow map is full to avoid deadlock among the involved threads.
28208832	COH-18361	Added the capability to be able to specify federation direct connect addresses via the <remote-addresses> element. This feature can be used in deployments where it may not be possible to use the preferred address lookup mechanism of connecting to the NameService running on the Coherence cluster port.

Oracle Coherence 12.2.1.3.2 for Java contains fixes for the following issues:
-----------------------------------------------------------------------------
29046131	COH-18849	Enhanced Coherence reports (cache-effectiveness and service) to include additional attributes.
29010638	COH-18821	Fixed an issue where a deadlock on a cache resource may occur when using federation.
29006212	COH-18820	Enhanced the Coherence*Web context parameter coherence-session-debug-logging-filter to enter an includes mode as opposed to the default exclude mode (see documentation for syntax).
28926172	COH-18769	Fixed a race condition that could cause a task being executed by the DaemonPool to be incorrectly cancelled while the guardian is in recovery mode.
28919001	COH-18766	Fixed an issue where entries marked for expiration may not be evicted from the cache if a partition transfer is currently in progress.
28890946	COH-18753	Fixed an issue in NearCache where the front map can have stale values if synthetic updates occur to previously fetched entries.
28890516	COH-18752	Fixed a journal storage leak which can occur when releasing backups of elastic data during cluster partition redistribution.
28879709	COH-18740	Fixed a timing issue with persistence and dynamic quorum when nodes are first starting.
28696142	COH-18625	Introduced a minor performance improvement to the MessageBus buffer allocation manager.
28640165	COH-18578	Removed an unnecessary thread dump action and log entry that is initiated when a member aborts joining a service in the cluster.
28620411	COH-18568	Fixed a logical deadlock where index rebuilding could block indefinitely waiting for a backing map event to be processed while other threads are blocked waiting for the indices to be available.
28599916	COH-18556	Reduced memory pressure when issuing an on-demand persistence snapshot.
28550573	COH-18520	Fixed an issue where a session may not be reaped when HTTP servlet requests are not completed due to an error (e.g. broken pipe).
28528643	COH-18511	Disabled automatic heapdumps which were added previously for debugging purposes.
28520700	COH-18509	Fixed an issue where partition distribution takes significantly longer due to a large number of caches.
28425895	COH-18471	Updated the documentation in coherence-cache-config.xsd to more clearly indicate where <federated-scheme> can be used and what its sub-elements are.
28424356	COH-18467	Fixed an issue when recovering a cache interleaves with a cache destroy.
28408555	COH-18463	Fixed an issue where partition transfer does not complete to concurrent index rebuild.
28395465	COH-18458	Fixed an intermittent issue in Coherence*Web where an IOException may be thrown while the SessionReaperDaemon is running.
28393499	COH-18457	Fixed an issue where a near-scheme with autostart set to true backed by a federated-scheme results in a ClassCastException on startup.
28379863	COH-18447	Upgraded included JLine to version 2.14.6.
28354970	COH-18439	Fixed an issue where *Extend listener registrations may result in the ProxyService being restarted.
28353340	COH-18437	Fixed an issue where a NullPointerException may be thrown on a federation startWithNoBacklog operation.
28352692	COH-18436	Fixed an issue where a TMB connection could be stuck repeatedly migrating itself.
28342738	COH-18433	Fixed an issue where a service can be terminated with ClassCastException if index creation takes a long time to complete.
28295333	COH-18412	Fixed an issue when using GARs where a custom ConfigurableCacheFactory without a configure(XmlElement) method throws an exception.
28280125	COH-18404	Fixed an issue where an unhandled RequestTimeoutException on Channel close may occur on a CPU or memory constrained *Extend client or proxy server.
28256434	COH-18388	Fixed an issue where EOFException is thrown when reading from PersistenceStore.
28255688	COH-18387	Fix an issue where UnsupportedOperationException is thrown when a cache operation is invoked before cache storage is fully initialized.
28240730	COH-18378	Added cyclic redundancy check (CRC) for message delivery to detect message corruption on wire. The feature is disabled by default and can be enabled by -Dcom.oracle.common.internal.net.socketbus.SocketBusDriver.crc=true.
28228951	COH-18376	Fixed an issue where MapListener events were being issued for non mutating requests, such as a get request, on NearCaches.
28217117	COH-18367	Fixed an issue where dispatching a MEMBER_LEFT event can lead to a NullPointerException.
28188185	COH-18336	Fixed an issue where calling truncate on a NearCache can result in its MBean being unregistered, and will remain so even after the NearCache is repopulated.
28172075	COH-18326	Fixed an issue where an IllegalStateException may be logged when federation changes cannot be applied due to quorum not being met.
27840434	COH-18110	Fixed an issue where a federated update may be skipped and not applied at destination participants in some rare scenarios.

Oracle Coherence 12.2.1.3.1 for Java contains fixes for the following issues:
-----------------------------------------------------------------------------
28223031	COH-18373	Fixed an issue where an IllegalArgumentException is thrown if cache destroy or creation occurs concurrently with partition transfer.
28221073	COH-18370	Fixed an issue where persistence recovery can hang with "Unreachable partitionSet".
28207405	COH-18355	Improved the performance and the calculated storage cost calculation of an index when using the BINARY unit-calculator.
28193327	COH-18340	Changed the cache type assertion mismatch log message (when the cache configuration and runtime type assertions are mismatched) to be emitted only once.
28136994	COH-18311	Fixed an issue where an "Address already in use" BindException may be thrown by UdpSocket.rebind.
28094772	COH-18284	Fixed an issue where a service thread can be blocked waiting for backing map eviction during backup transfer, which could lead to some cascading issues like service joining and async index creation problems.
28072632	COH-18281	Fixed an issue where a member leaving can result in a cache lock never being released.
28065036	COH-18269	Changed the client side log message "This thread was interrupted while waiting for result." to be a warning instead of an error level message.
28063514	COH-18266	Fixed critical log messages to be displayed at INFO level.
28028978	COH-18227	Fixed an issue where the ConnectionManager MBean MessagingDebug attribute is read only.
28004307	COH-18210	Fixed a memory leak issue that is caused by an unsent map event.
27986678	COH-18205	Changed AbstractPofPath.navigate to behave like ChainedExtractor when an intermediate result in the path is null, instead of throwing a NullPointerException.
27912456	COH-18173	Fixed an issue where the RAM and Flash journal collector threads could deadlock.
27894916	COH-18150	Reduced the cost of guardian generated thread dumps which had occasionally resulted in long JVM pauses.
27876246	COH-18140	Fixed an issue where a locally backlogged federation node could fail to receive new messages.
27875419	COH-18138	Fixed an issue where federation connections may be unnecessarily closed in active-active topologies.
27868699	COH-16254	Improved the performance of cache creation & destruction with persistence enabled by creating necessary data structures on demand.
27862015	COH-18131	Fixed an issue where a custom proxy service which overrides addMapListener() may result in NamedCache Extend Channels being incorrectly closed.
27861417	COH-18130	Fixed an issue where an asynchronous index creation thread could hang forever.
27848089	COH-18115	Fixed an issue where a failed TCP connection could fail to be migrated if the failure occurred upon startup.
27846288	COH-18111	Fixed an issue where federation does not properly release its connection to a remote cluster if there is an error during connection establishment.
27832087	COH-18096	Fixed an issue with POF annotations and adding primitive properties when evolving an object.
27818455	COH-18092	Fixed an issue present with storage nodes that issue query requests (specifically ArrayFilter derivatives) to both remote and local nodes that can cause mutation of the Filter prior to sending to remote nodes.
27818137	COH-18091	Fixed an issue where an IllegalArgumentException with a null identifier could be thrown if persistent store operation throws IOException, for example from insufficient device space.
27811869	COH-18079	Reduced contention around the AssociatedQueue component.
27780459	COH-18047	Increased log level of SSLExceptions to warnings.
27766911	COH-18031	Fixed an issue where active persistence recovery could be disabled when transitioning from non-federated to federated configuration, resulting in an unrecoverable ENDANGERED state.
27738956	COH-18004	Fixed an issue where a NullPointerException can be thrown if requests arrive before a service has fully joined the cluster.
27731558	COH-18001	Fixed an issue where federation ReplicateAll SYNCING and SYNCED events may be emitted prematurely.
27707129	COH-17970	Fixed an issue where setting the guardian to "logging" mode could cause handling of failed TMB connections to be ignored.
27704393	COH-17969	Fixed an issue where the Partition Ownership suggestion message was not being logged at the default log level 5.
27662781	COH-17940	Removed some large and unnecessary federation level 7 and 9 log messages.
27661825	COH-17939	Fixed an issue where federation may stop sending updates for some partitions.
27639671	COH-17925	Fixed an issue where there may be significant delays in processing federation stop or pause operations.
27639638	COH-17924	Fixed an issue where a NullPointerException may be thrown during federation remote cluster address lookup.
27615158	COH-17907	Fixed an issue where federated changes are being skipped instead of retried when the change is temporarily disallowed due to quorum.
27613955	COH-17906	Fixed an issue where data loss could occur if persistent store recovery is interleaved with ensureCache operations.
27593019	COH-17894	Fixed an issue where the thread names of some federation threads are missing the service name or other descriptions.
27585336	COH-17883	Fixed an issue where a NullPointerException could be thrown during federation service startup.
27585328	COH-17882	Fixed an issue where HttpSessionBindingListener.valueUnbound is called unnecessarily.
27572986	COH-17871	Fixed an issue where the end of a network outage could cause excessive logging if a quorum policy is configured.
27554580	COH-17857	Fixed an issue where Coherence*Web session data is not cleaned up during the reaping process.
27530247	COH-17822	Fixed an issue where some Coherence*Web reports do not work correctly.
27529445	COH-17821	Fixed an issue where the evictions-total field in cache-usage.txt can be empty when extendedmbeanname is set to true.
27485094	COH-17809	Fixed an issue where federation message request timeouts cause federation to transition to the ERROR state.
27450747	COH-17783	Fixed an issue where active persistence recovery may not release file system locks, which in-turn disallows recovery, resulting in data loss.
27425975	COH-17762	Fixed an issue where an IllegalStateException may be thrown by federation when Coherence members join or leave the cluster.
27409089	COH-17749	Fixed an issue where a cluster may not be completely stopped before allowing a cluster service restart, which can lead to an OutOfMemoryError.
27376523	COH-17731	Greatly reduced the time it takes for an ejected member to detect that it has been removed from the cluster.
27376204	COH-17730	Fixed an issue where a concurrent cluster and service restart could result in a failed security check.
27364288	COH-17717	Fixed an issue where an ArrayIndexOutOfBoundsException may be thrown by the ConfigurableAddressProvider.
27361228	COH-17707	Fixed an issue where a Hotcache adapter process can abnormally terminate (abend) while running in tx mode.
27321582	COH-17686	Fixed an issue where Coherence*Web can leak memory when HttpServletRequest#changeSessionId() is called.
27301934	COH-17681	Fixed an issue where NamedCache.clear() on partitioned backing maps does not call the CacheStore erase methods.
27252028	COH-17614	Fixed an issue where the partition assignment strategy repeatedly fails to find a distribution that satisfies backup strength and balance.
27250717	COH-17613	Fixed an issue where a StackOverflowError can be raised by QueryHelper.createFilter() when the filter has an identifier on each side of the expression.
27235054	COH-17597	Fixed an issue where a spurious thread interrupt may be sent to a stopping Coherence service.
27199415	COH-17580	Improved timeout based death determinations to historic communication statistics and to prefer removal of non-storage members over storage members.
27190914	COH-17573	Fixed an issue where an Extend client may leak memory when unable to connect to a proxy server.
27154490	COH-17560	Fixed an issue where migrating partitions may result in federation ReplicateAll statistics never reaching their completed values.
27147254	COH-17557	Fixed an issue when recovering from persistence while the process is shutting down.
27122544	COH-17810	Fixed multiple issues where the quorum policy could be ineffective during long network outages.
27114760	COH-17528	Fixed an issue where certain fields like HeapUsed, JVM Uptime, HeapCommitted, etc. were missing from the memory-status.txt JMX report.
27111074	COH-17525	Fixed the issue where CacheService.setContextClassLoader does not propagate the serializer change to the BackingMapContext.
27092998	COH-17512	Fixed a thread safety issue with the RefreshableAddressProvider.
27062171	COH-17501	Fixed an issue where the federation Destination MBean's ReplicateAll stats may not update for small or empty caches.
27043687	COH-17486	Fixed an issue where TMB connections could repeatedly fail to migrate when processing large messages on a slow network.
27030308	COH-17480	Fixed an issue where the UPDATE Operation in HotCache for Entities using aggregate types (using @EmbeddedId/@Embedable) for Primary Keys could cause the GoldenGate Extract process to terminate with a NullPointerException.
27029536	COH-17479	Fixed an issue where close() may not be called on Closable ExpiryPolicies, CacheLoaders and CacheWriters when a JCache PartitionedCache is destroyed.
27010997	COH-17058	Fixed an issue in simple query record reporter where the results from multiple storage servers may not be combined or combined correctly.
26962666	COH-17430	Fixed an issue where a ClassCastException may be thrown when closing a JCache cache with a CacheEntryListener that is Closeable.
26929440	COH-17419	Fixed an issue where there can be an assertion failure in AbstractJournalRM.JournalImpl.dispose due to dispose being called twice on an instance.
26909061	COH-17409	Fixed an issue where using an index in aggregation calls can lead to retrieval of stale cache entries.
26870228	COH-17392	Fixed an issue where a service can go into the endangered state and not complete recovery during a cluster restart if dynamic quorum or active persistence is used.
26864993	COH-17388	Fixed an issue where garbage collection of a large federation backlog may result in high CPU usage or Guardian timeouts.
26849889	COH-17383	Fixed an issue where an Extend client may throw RequestTimeoutExceptions when sending a large number of requests to a large number of caches concurrently.
26844974	COH-17379	Added back public class com.tangosol.coherence.config.xml.prepreprocessor.CacheDefaultPreprocessor.
26826876	COH-17359	Fixed an issue where method column type was not working in reports.
26812309	COH-17353	Fixed an issue where partition distribution can be slightly unbalanced.
26790950	COH-17328	Removed the stop() call from the federation start with sync operation.
26775617	COH-17320	Fixed an issue where file descriptors were leaked until the next full GC as a result of using lambdas with Coherence.
26737024	COH-17294	Fixed an issue where TMB connection migration could result in a new connection being opened rather than the prior one being migrated.
26726567	COH-17285	Fixed a memory leak in TMB related to messages sent during the termination of the recipient.
26725685	COH-17283	Fixed an issue where the POF config generator can potentially fail with a NullPointerException.
26725338	COH-17281	Fixed an issue where NearCache MBeans are not being unregistered when the corresponding CacheService is shut down.
26712326	COH-17272	Fixed an issue where a filter based query may not return all matching entries.
26696812	COH-17265	Fixed an issue in NonBlockingFiniteStateMachine that can result in corruption of internal state.
26674861	COH-17250	Fixed an issue where setting the com.oracle.exa system property to false is not respected.
26662631	COH-17241	Fixed an issue where index maps could become inconsistent with their backing map.
26608557	COH-17195	Fixed an issue where a negative array lookup can be induced in rare and random scenarios.
26571852	COH-17180	Added more information to the exception that is thrown when processing certain types of malformed Extend messages.
26554964	COH-17162	Fixed an issue where a StackOverflowError may occur when closing connections in Solaris IPMP environments.
26541868	COH-17150	Fixed an issue with the hash code implementations of some internal classes used in Java stream processing.
26449379	COH-17306	Fixed an issue where Coherence threads can deadlock when partition redistribution is happening concurrently with cache expiry events.
26260517	COH-16995	Fixed an issue with active persistence where data loss may occur during cluster shutdown.
25930966	COH-16816	Fixed an issue where the Management service could not be restarted.
25908156	COH-16798	Fixed an issue where an IllegalStateException could be thrown during serialization of Ack packets.
25689563	COH-16638	Added additional tracing information, such as cache and service names, to Extend log messages.
24608102	COH-15977	Fixed an issue where Session.getCache could return a destroyed or released cache.
22901874	COH-15024	Fixed an issue where entry processors and aggregators that implement PriorityTask have their timeout values ignored when executed from Extend clients.
21967696	COH-13983	Added support for the JCache 1.1.0 API.
